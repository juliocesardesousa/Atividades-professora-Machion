//Exercicio 4: Ler uma distância em km, transformar para milhas (MILHAS=KM/1,61)

import java.util.Scanner;
public class DistanciaMilhas {
    public static void main (String [] args) {
        Scanner scanner = new Scanner (System.in);
        System.out.print ("Digite os KM: ");
        double km = scanner.nextDouble();
        double a = 1.61;
        double milhas = km / a;
        System.out.println ("Km transformado em milhas: " + milhas);
        scanner.close(); 
    }
}