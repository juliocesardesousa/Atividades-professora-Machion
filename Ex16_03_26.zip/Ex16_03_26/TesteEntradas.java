import java.util.Scanner;

public class TesteEntradas {
    public static void main (String[] args) {
        //declara e instancia um objeto Scanner
        Scanner scanner = new Scanner(System.in);
        //exibe mensagem para o usuário
        System.out.print("digite um inteiro: ");
        //declara um inteiro e faz a leitura
        int valorInteiro = scanner.nextInt();
        //exibe mensagem para o usuário
        System.out.print("digite um valor com casas decimais: ");
        //declara o Double  e faz a leitura
        double valorDecimal  = scanner.nextDouble();
        //exibe mensagem para o usuário
        System.out.print("digite verdadeiro (true) ou falso (false): ");
        //declara o Boolean e faz a leitura
        boolean eVerdade = scanner.nextBoolean();
        //exibir os valores digitados
        System.out.println ("veja os valorres digitados: ");
        System.out.println ("o Inteiro: " + valorInteiro);
        System.out.println ("o Decimal: " + valorDecimal);
        System.out.println ("o Verdadeiro ou Falso: " + eVerdade);
        //libera o recurso
        scanner.close();
        
    }
}