//Execicio 2: Digite 3 numeros, faça com que os 2 primeiros somam e o 3 numero multiplique o resultado da soma
import java.util.Scanner;

public class MultiplicaSoma {
    public static void main (String[] args) {
    //declarando e instanciando o Scanner
    Scanner scanner = new Scanner (System.in);
    //Entrada de dados e declaração das variáveis
    System.out.print ("Digite o primeiro numero: ");
    double primeiroNumero = scanner.nextDouble();
    System.out.print ("Digite o segundo numero: ");
    double segundoNumero = scanner.nextDouble();
    System.out.print ("Digite o terceiro numero: ");
    double terceiroNumero = scanner.nextDouble();
    //Processamento
    double soma = primeiroNumero + segundoNumero;
    System.out.println ("soma dos dois primeiros numeros = " + soma);
    double multiplicasoma = soma * terceiroNumero;
    System.out.println ("Multiplicação do terceiro numero com o resultado da soma = " + multiplicasoma);
    scanner.close();
    }
}