//Exercicio 3: Ler um inteiro e exibir seu sucessor e seu antecessor
import java.util.Scanner;

public class SucessorAntecessor {
    public static void main (String [] args) {
        //declarando o int do Sucessor e Antecessor
        int sucessor = 1;
        int antecessor = -1;
        //declarando e instanciando o Scanner
        Scanner scanner = new Scanner (System.in);
        //entrada de dados e declaração das variáveis
        System.out.print ("digite o numero: ");
        int oNumero = scanner.nextInt();
        //processamento
        int resultadoSucessor = oNumero + sucessor;
        System.out.println ("O sucessor do numero: " + resultadoSucessor);
        int resultadoAntecessor = oNumero + antecessor;
        System.out.println ("O antecessor do numero: " + resultadoAntecessor);
        scanner.close();
    }
    
}